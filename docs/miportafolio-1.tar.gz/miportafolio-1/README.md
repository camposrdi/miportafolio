# miportafolio

Actividad 3 
Bootcamp Front-End Web Developer 

Consistia en la elaboración de mi portafolio profesional con html, css3  y bootstrap. 

Se actualiza css y cada sección. 
